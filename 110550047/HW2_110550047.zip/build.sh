chmod u+x *.sh
make
mkdir build
ls -a
mv server build/